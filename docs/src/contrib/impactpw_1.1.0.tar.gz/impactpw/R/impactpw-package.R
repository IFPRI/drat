# Authors: Abhijeet Mishra <a.mishra@cgiar.org>, Claude (Anthropic)

#' impactpw: World Price Database Generation for the IMPACT Model
#'
#' Generates a world price database (`PWDatabase.gdx`) for the IMPACT model
#' by combining FAOSTAT trade data, World Bank Pink Sheet commodity prices,
#' and an existing IMPACT model run. Prices are averaged over a user-defined
#' base year window (default 2020–2022, centred on IMPACT's 2021 base year).
#'
#' @section Main function:
#' * [generate_pw_database()] — single call to produce the output GDX.
#'
#' @docType package
#' @name impactpw-package
"_PACKAGE"

## Suppress R CMD CHECK notes for data.table/dplyr column name usage
utils::globalVariables(c(
    "Element Code", "Year", "Area", "Item Code", "Item",
    "Element", "Unit", "Value",
    "itemcode", "item", "elementcode", "element", "yrs", "unit", "value",
    "j", "is_any_dup", "domaincode", "c", "src",
    "indicator", "model",
    # internal data objects
    "jcodes", "fmc", "comms"
))
