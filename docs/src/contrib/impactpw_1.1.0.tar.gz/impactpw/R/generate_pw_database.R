#' Generate the IMPACT world price database
#'
#' Combines FAOSTAT trade-based implicit unit values, World Bank Pink Sheet
#' prices, and an existing IMPACT model run (`PW00`) into a single GDX file
#' (`PWDatabase.gdx`) suitable for use in IMPACT price calibration.
#'
#' Prices are averaged over `base_years` (default `2020:2022`), which centres
#' on 2021 — IMPACT's standard base year.
#'
#' @param faostat_trade_file Path to the FAOSTAT normalized trade CSV
#'   (`Trade_CropsLivestock_E_All_Data_(Normalized).csv`). Original data from `https://www.fao.org/faostat/en/#data/TCL`
#' @param pinksheet_file Path to the WB Pink Sheet xlsx file
#'   (`CMO-Historical-Data-Annual.xlsx`). Original data from `https://thedocs.worldbank.org/en/doc/18675f1d1639c7a34d463f59263ba0a2-0050012025/related/CMO-Historical-Data-Annual.xlsx`
#' @param impact_gdx_file Path to an existing IMPACT run GDX containing the
#'   `PW00` parameter.
#' @param output_gdx_file Path where the output `PWDatabase.gdx` will be written.
#' @param base_years Integer vector of years to average over. Default `2020:2022`.
#'
#' @return Invisibly returns the combined price data frame. The primary output
#'   is the GDX file written to `output_gdx_file`.
#'
#' @examples
#' \dontrun{
#' generate_pw_database(
#'   faostat_trade_file = "Trade_CropsLivestock_E_All_Data_(Normalized).csv",
#'   pinksheet_file     = "CMO-Historical-Data-Annual.xlsx",
#'   impact_gdx_file    = "SSP2-MRI-370-379.gdx",
#'   output_gdx_file    = "PWDatabase.gdx"
#' )
#' }
#'
#' @importFrom data.table rbindlist
#' @importFrom gamstransfer Container
#' @importFrom DOORMAT readGDX
#' @export
#' @author Abhijeet Mishra, Claude (Anthropic)
generate_pw_database <- function(faostat_trade_file,
                                 pinksheet_file,
                                 impact_gdx_file,
                                 output_gdx_file,
                                 base_years = 2020:2022) {

    # Validate inputs
    for (f in c(faostat_trade_file, pinksheet_file, impact_gdx_file)) {
        if (!file.exists(f)) stop("File not found: ", f)
    }

    # --- FAOSTAT prices ---
    tmp1 <- .process_faostat(faostat_trade_file, base_years)
    tmp1$src <- "FAOSTAT"

    # --- Pink Sheet prices (averaged over base_years) ---
    ps <- .process_pinksheet(pinksheet_file, base_years)
    tmp2 <- ps |>
        dplyr::group_by(c) |>
        dplyr::summarise(value = mean(value, na.rm = TRUE), .groups = "drop")
    tmp2$src <- "WBG"

    # --- IMPACT baseline PW00 ---
    message("Reading IMPACT GDX: PW00...")
    tmp3 <- DOORMAT::readGDX(gdx = impact_gdx_file,
                             name = "PW00",
                             quick_df = TRUE)$data
    tmp3$src <- "IMPACT"

    # --- Combine ---
    pwfinal <- data.table::rbindlist(l = list(tmp1, tmp2, tmp3), fill = TRUE)

    # --- Write GDX ---
    message("Writing GDX to: ", output_gdx_file)
    m <- gamstransfer::Container$new()
    c_set   <- m$addSet("c",   records = unique(pwfinal$c),   description = "commodities")
    src_set <- m$addSet("src", records = unique(pwfinal$src), description = "data source")
    m$addParameter("PWDataBase",
                   domain  = c(c_set, src_set),
                   records = pwfinal[, c("c", "src", "value")])
    m$write(output_gdx_file)

    message("Done. PWDatabase.gdx written successfully.")
    invisible(pwfinal)
}
