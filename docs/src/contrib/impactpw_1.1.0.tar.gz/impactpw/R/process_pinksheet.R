# Authors: Abhijeet Mishra <a.mishra@cgiar.org>, Claude (Anthropic)

#' Process World Bank Pink Sheet data into world prices
#'
#' Reads the WB Commodity Price Data (Pink Sheet) annual nominal prices sheet,
#' filters to IMPACT-relevant commodities, converts units to USD/mt, and
#' averages over the specified base years.
#'
#' @param pinksheet_file Path to the WB Pink Sheet xlsx file
#'   (e.g., `CMO-Historical-Data-Annual.xlsx`).
#' @param base_years Integer vector of years to average over. Default `2020:2022`.
#'
#' @return A data frame with columns `c` (IMPACT commodity code), `yrs`, `value` (USD/mt),
#'   and `model` = `"WBG"`.
#'
#' @importFrom openxlsx2 read_xlsx
#' @importFrom dplyr filter group_by summarise mutate
#' @importFrom tidyr pivot_longer
#' @importFrom collapse join
#' @keywords internal
#' @author Abhijeet Mishra, Claude (Anthropic)
.process_pinksheet <- function(pinksheet_file, base_years = 2020:2022) {

    message("Reading Pink Sheet data...")
    ps <- openxlsx2::read_xlsx(file = pinksheet_file,
                               sheet = "Annual Prices (Nominal)",
                               start_row = 7,
                               skip_empty_cols = TRUE)
    names(ps)[1] <- "yrs"

    ps <- ps |> tidyr::pivot_longer(!yrs, names_to = "indicator", values_to = "value")

    # Extract units row
    psunits <- ps |>
        dplyr::filter(is.na(yrs)) |>
        dplyr::filter(!is.na(value))
    psunits$yrs <- NULL
    names(psunits)[2] <- "unit"

    ps <- ps |> dplyr::filter(!is.na(yrs))
    ps <- ps[!ps$value %in% c(".", "..", "...", "\u2026"), ]

    ps <- collapse::join(x = ps, y = psunits, on = "indicator")
    ps$value <- round(as.numeric(ps$value), 3)
    ps$yrs <- as.integer(ps$yrs)

    ps <- ps |> dplyr::filter(yrs %in% base_years)

    # Join to IMPACT commodity crosswalk
    ps <- collapse::join(x = ps, y = comms, on = "indicator")
    ps <- ps |> dplyr::filter(!is.na(c))

    # Convert $/kg to $/mt
    ps$value[ps$unit %in% "($/kg)"] <- ps$value[ps$unit %in% "($/kg)"] * 1000
    ps$unit <- "USD/mt"

    ps <- ps |>
        dplyr::group_by(c, yrs) |>
        dplyr::summarise(value = mean(value, na.rm = TRUE), .groups = "drop")

    ps$model <- "WBG"

    return(ps)
}
