#' Process FAOSTAT trade data into world prices
#'
#' Reads the FAOSTAT normalized trade CSV, filters to global export quantity
#' (element 5910) and export value (element 5922) for the specified years,
#' and computes implicit unit values (USD/mt) per IMPACT commodity.
#'
#' @param faostat_trade_file Path to the FAOSTAT normalized trade CSV
#'   (e.g., `Trade_CropsLivestock_E_All_Data_(Normalized).csv`).
#' @param base_years Integer vector of years to average over. Default `2020:2022`.
#'
#' @return A data frame with columns `c` (IMPACT commodity code) and `value` (USD/mt).
#'
#' @importFrom data.table fread rbindlist
#' @importFrom dplyr filter group_by summarise mutate n n_distinct
#' @importFrom collapse join
#' @importFrom janitor get_dupes
#' @keywords internal
#' @author Abhijeet Mishra, Claude (Anthropic)
.process_faostat <- function(faostat_trade_file, base_years = 2020:2022) {

    message("Reading FAOSTAT trade data...")
    fao_raw <- data.table::fread(faostat_trade_file)

    faoclp <- fao_raw |>
        dplyr::filter(`Element Code` %in% c(5910, 5922),
                      Year %in% base_years,
                      Area %in% "World") |>
        dplyr::group_by(`Item Code`, Item, `Element Code`, Element, Year, Unit) |>
        dplyr::summarise(Value = sum(Value, na.rm = TRUE), .groups = "drop")

    names(faoclp) <- c("itemcode", "item", "elementcode", "element", "yrs", "unit", "value")

    # Resolve FAO master codes to IMPACT j-codes
    fmc_work <- fmc |>
        dplyr::mutate(is_any_dup = dplyr::n() > 1, .by = item)

    fmc_work <- collapse::join(x = fmc_work, y = jcodes, on = "itemcode")

    fmc1 <- fmc_work[!fmc_work$is_any_dup, ]
    fmc2 <- fmc_work |>
        dplyr::filter(is_any_dup == TRUE) |>
        dplyr::group_by(item) |>
        dplyr::mutate(j = if (dplyr::n_distinct(j, na.rm = TRUE) == 1) {
            j[!is.na(j)][1]
        } else {
            j
        }) |>
        dplyr::filter(!is.na(j)) |>
        dplyr::ungroup()

    fmc_resolved <- rbind(fmc1, fmc2)
    fmc_resolved <- fmc_resolved[!is.na(fmc_resolved$j), ]
    fmc_resolved$is_any_dup <- NULL

    # Join to trade data
    faoclp <- collapse::join(x = faoclp,
                             y = fmc_resolved[, c("itemcode", "j")],
                             on = "itemcode",
                             multiple = FALSE)

    removed <- sort(unique(faoclp[is.na(faoclp$j), ]$item))
    if (length(removed) > 0) {
        message("Items removed (no IMPACT j-code match):\n  ",
                paste(removed, collapse = "\n  "))
    }

    faoclp <- faoclp[!is.na(faoclp$j), ]

    # Compute implicit unit value: export value / (export quantity / 1000) -> USD/mt
    prices <- faoclp |>
        dplyr::group_by(j, elementcode, element) |>
        dplyr::summarise(value = sum(value, na.rm = TRUE), .groups = "drop") |>
        dplyr::group_by(j) |>
        dplyr::reframe(value = value[elementcode == 5922] / (value[elementcode == 5910] / 1000))

    prices$j <- sub("^j", "c", prices$j)
    names(prices)[1] <- "c"

    return(prices)
}
