# impactpw

**World Price Database Generation for the IMPACT Model**

`impactpw` generates a `PWDatabase.gdx` file for use in IMPACT model price calibration by combining:

- FAOSTAT normalized trade data (implicit unit values)
- World Bank Commodity Price Data (Pink Sheet)
- An existing IMPACT model run (`PW00` parameter)

Prices are averaged over a user-defined base year window (default: 2020–2022, centred on IMPACT's 2021 base year).

---

## Installation

```r
# install.packages("remotes")
remotes::install_github("IFPRI/impactpw")
```

---

## Usage

```r
library(impactpw)

generate_pw_database(
  faostat_trade_file = "Trade_CropsLivestock_E_All_Data_(Normalized).csv",
  pinksheet_file     = "CMO-Historical-Data-Annual.xlsx",
  impact_gdx_file    = "SSP2-MRI-370-379.gdx",
  output_gdx_file    = "PWDatabase.gdx",
  base_years         = 2020:2022   # default; centred on IMPACT base year 2021
)
```

---

## Required input files

| Argument | Source | Notes |
|---|---|---|
| `faostat_trade_file` | [FAOSTAT](https://www.fao.org/faostat/en/#data/TCL) | Download "Trade: Crops and livestock products", normalized format |
| `pinksheet_file` | [World Bank](https://www.worldbank.org/en/research/commodity-markets) | `CMO-Historical-Data-Annual.xlsx` |
| `impact_gdx_file` | IMPACT model run | Must contain the `PW00` parameter |

---

## Bundled data

The following reference data ship with the package (`inst/extdata/`):

- `Sets.xlsx` — IMPACT commodity set definitions (j-codes)
- `FAOSTAT_data_3-5-2026.csv` — FAOSTAT item code–name crosswalk. Downloaded from `item` tag in `https://www.fao.org/faostat/en/#definitions`

---

## Authors

- Abhijeet Mishra (IFPRI) — [ORCID 0000-0002-8287-9922](https://orcid.org/0000-0002-8287-9922)
- Claude (Anthropic)
