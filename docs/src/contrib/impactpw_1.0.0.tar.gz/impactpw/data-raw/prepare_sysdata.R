# Authors: Abhijeet Mishra <a.mishra@cgiar.org>, Claude (Anthropic)
# Run this script once (data-raw/prepare_sysdata.R) to regenerate R/sysdata.rda
# It reads Sets.xlsx and FAOSTAT_data csv from inst/extdata and saves
# internal package data.

library(data.table)
library(openxlsx2)
library(dplyr)

# ---- jcodes from Sets.xlsx ----
f <- system.file("extdata", "Sets.xlsx", package = "impactpw")

j1 <- openxlsx2::read_xlsx(file = f, sheet = "Commodities", start_row = 4, cols = 15:16, skip_empty_rows = TRUE)
j2 <- openxlsx2::read_xlsx(file = f, sheet = "Commodities", start_row = 4, cols = 18:19, skip_empty_rows = TRUE)
j3 <- openxlsx2::read_xlsx(file = f, sheet = "Commodities", start_row = 4, cols = 24:25, skip_empty_rows = TRUE)

names(j1) <- names(j2) <- names(j3) <- c("itemcode", "j")
jcodes <- data.table::rbindlist(l = list(j1, j2, j3))

jcodes_additional <- data.frame(
    itemcode = c(329, 162, 271, 272, 237, 238, 267, 268, 269, 258, 259, 245),
    j = c("jcott", "jsugr", "jrpol", "jrpml", "jsbol", "jsbml", "jsnfl", "jsfol", "jsfml", "jpkol", "jpkml", "jgdml")
)

jtoml <- data.frame(itemcode = sort(c(332, 253, 291, 37, 61, 282, 298, 314, 335, 338, 342)), j = "jtoml")
jcott <- data.frame(itemcode = sort(c(329, 767)), j = "jcott")

jcodes <- data.table::rbindlist(l = list(jcodes, jcodes_additional, jtoml, jcott))
jcodes <- unique(jcodes)

# ---- FAO master codes ----
fmc_path <- system.file("extdata", "FAOSTAT_data_3-5-2026.csv", package = "impactpw")
fmc <- data.table::fread(fmc_path)
fmc <- fmc[, c(1, 3, 4)]
names(fmc) <- c("domaincode", "itemcode", "item")
fmc$domaincode <- NULL
fmc$item <- tolower(fmc$item)
fmc <- unique(fmc)

# ---- Pinksheet commodity crosswalk ----
comms <- data.frame(
    indicator = c("Banana, Europe", "Banana, US",
                  "Barley",
                  "Beef",
                  "Chicken",
                  "Cocoa",
                  "Coffee, Arabica", "Coffee, Robusta",
                  "Cotton, A Index",
                  "Groundnut oil", "Groundnuts",
                  "Lamb **",
                  "Maize",
                  "Palm kernel oil", "Palm oil",
                  "Rice, Thai 25% ", "Rice, Thai 5% ", "Rice, Thai A.1", "Rice, Viet Namese 5%",
                  "Soybean meal", "Soybean oil", "Soybeans",
                  "Sugar, world",
                  "Tea, avg 3 auctions",
                  "Wheat, US HRW", "Wheat, US SRW",
                  "Sorghum"),
    c = c("cbana", "cbana",
          "cbarl",
          "cbeef",
          "cpoul",
          "ccoco",
          "ccafe", "ccafe",
          "ccott",
          "cgdol", "cgrnd",
          "clamb",
          "cmaiz",
          "cpkol", "cplol",
          "crice", "crice", "crice", "crice",
          "csbml", "csbol", "csoyb",
          "csugr",
          "cteas",
          "cwhea", "cwhea",
          "csorg")
)

# ---- Save internal data ----
usethis::use_data(jcodes, fmc, comms, internal = TRUE, overwrite = TRUE)
