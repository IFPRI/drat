## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- eval=FALSE--------------------------------------------------------------
#  # Installing from r-universe of IFPRI
#  install.packages('KIRAN',
#                   repos='http://https://ifpri.r-universe.dev/',
#                   dependencies = TRUE)
#  

## ---- eval=FALSE--------------------------------------------------------------
#  library(KIRAN)
#  setKiran()
#  

