## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- warning=FALSE-----------------------------------------------------------
library(ARIA)

## ----eval=FALSE---------------------------------------------------------------
#  my_impact_results_folder <- "<path/to/impact/folder>/OutputFiles/Scenarios"

## ----eval=FALSE---------------------------------------------------------------
#  appIMPACT(folder = my_impact_results_folder)

## ----eval=FALSE---------------------------------------------------------------
#  appIMPACT(folder = "<path/to/impact/folder>/OutputFiles/Scenarios")

