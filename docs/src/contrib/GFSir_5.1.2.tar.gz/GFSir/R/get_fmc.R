#' Build FAO Master Codes Table
#'
#' Reads j-code commodity mappings from the bundled \code{Sets.xlsx} and
#' \code{FAOSTAT_data_3-5-2026.csv} files shipped with the package, resolves
#' duplicates, and returns a clean item-to-j-code crosswalk.
#'
#' @return A \code{data.frame} with columns:
#' \describe{
#'   \item{itemcode}{Integer FAO item code.}
#'   \item{item}{Lowercase FAO item name.}
#'   \item{j}{IMPACT j-code string (e.g. \code{"jwhea"}).}
#' }
#'
#' @details
#' The function reads three column ranges from the \code{Commodities} sheet of
#' \code{Sets.xlsx} to build the j-code lookup, appends several hardcoded
#' corrections, then joins against the FAO master code list. Duplicate item
#' names that map to a single unambiguous j-code are resolved automatically;
#' those that cannot be resolved are dropped with a warning.
#'
#' Duplicate checks are performed at three stages using
#' \code{\link[janitor]{get_dupes}}. A warning is issued if any are found.
#'
#' @importFrom openxlsx2 read_xlsx
#' @importFrom data.table fread rbindlist
#' @importFrom collapse join
#' @importFrom janitor get_dupes
#' @importFrom dplyr mutate filter group_by ungroup n n_distinct
#'
#' @examples
#' \dontrun{
#' fmc <- get_fmc()
#' head(fmc)
#' }
#'
#' @export
get_fmc <- function() {

    item <- is_any_dup <- j <- NULL

    sets_path <- system.file("extdata", "impactsets.xlsx", package = "GFSir")
    fao_path  <- system.file("extdata", "faocodes.csv", package = "GFSir")

    if (sets_path == "") stop("impactsets.xlsx not found in inst/extdata.")
    if (fao_path == "")  stop("faocodes.csv not found in inst/extdata.")

    # Read j-code sets from Excel
    j1 <- openxlsx2::read_xlsx(file = sets_path,
                               sheet = "Commodities",
                               start_row = 4,
                               cols = 15:16,
                               skip_empty_rows = TRUE)

    j2 <- openxlsx2::read_xlsx(file = sets_path,
                               sheet = "Commodities",
                               start_row = 4,
                               cols = 18:19,
                               skip_empty_rows = TRUE)

    j3 <- openxlsx2::read_xlsx(file = sets_path,
                               sheet = "Commodities",
                               start_row = 4,
                               cols = 24:25,
                               skip_empty_rows = TRUE)

    names(j1) <- names(j2) <- names(j3) <- c("itemcode", "j")

    jcodes <- data.table::rbindlist(l = list(j1, j2, j3))

    jcodes_additional <- data.frame(
        itemcode = c(329, 162, 271, 272, 237, 238, 267, 268, 269, 258, 259, 245),
        j = c("jcott", "jsugr", "jrpol", "jrpml", "jsbol",
              "jsbml", "jsnfl", "jsfol", "jsfml", "jpkol", "jpkml", "jgdml")
    )

    jtoml <- data.frame(itemcode = sort(c(332, 253, 291, 37, 61, 282, 298, 314, 335, 338, 342)),
                        j = "jtoml")

    jcott <- data.frame(itemcode = sort(c(329, 767)), j = "jcott")

    jcodes <- data.table::rbindlist(l = list(jcodes, jcodes_additional, jtoml, jcott))
    jcodes <- unique(jcodes)

    dupes_jcodes <- janitor::get_dupes(jcodes)
    if (nrow(dupes_jcodes) > 0) warning("Duplicates found in jcodes.", immediate. = TRUE)

    # Read and clean FAO master codes
    fmc <- data.table::fread(fao_path)
    fmc <- fmc[, c(1, 3, 4)]
    names(fmc) <- c("domaincode", "itemcode", "item")
    fmc$domaincode <- NULL
    fmc$item <- tolower(fmc$item)

    dupes_fmc <- janitor::get_dupes(fmc, "item")
    if (nrow(dupes_fmc) > 0) message("Duplicates found in fmc by item.", immediate. = TRUE)

    fmc <- unique(fmc)
    fmc <- fmc %>%
        dplyr::mutate(is_any_dup = dplyr::n() > 1, .by = item)

    # Join jcodes
    fmc <- collapse::join(x = fmc, y = jcodes, on = "itemcode")

    fmc1 <- fmc[!fmc$is_any_dup, ]
    fmc2 <- fmc %>%
        dplyr::filter(is_any_dup == TRUE) %>%
        dplyr::group_by(item) %>%
        dplyr::mutate(j = if (dplyr::n_distinct(j, na.rm = TRUE) == 1) {
            j[!is.na(j)][1]
        } else {
            j
        }) %>%
        dplyr::filter(!is.na(j)) %>%
        dplyr::ungroup()

    fmc <- rbind(fmc1, fmc2)
    fmc <- fmc[!is.na(fmc$j), ]
    fmc$is_any_dup <- NULL

    dupes_final <- janitor::get_dupes(fmc)
    if (nrow(dupes_final) > 0) warning("Duplicates found in final fmc.", immediate. = TRUE)

    return(rbind(fmc[, -2]))
}
