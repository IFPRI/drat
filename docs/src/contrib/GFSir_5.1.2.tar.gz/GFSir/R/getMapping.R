#' getMapping
#'
#' @param type "region" or "crops". Region returns six CGIAR regions + developed
#' or developing countries + world. Crops returns IMPACT mapping for crops in
#' their more user friendly name.
#' @param file mapping file name
#'
#' @return mapping according to the type selected
#' @importFrom openxlsx2 read_xlsx
#' @export
#'
#' @examples
#' \dontrun{
#' getMapping()
#' }
#' @author Abhijeet Mishra
getMapping <- function(type = "region", file = "mapping.xlsx") {
    mapping <- NULL
    mapping_file <- system.file("extdata", file, package = "GFSir")

    duplicated_message <- function(mapping) {
        if (any(duplicated(mapping))) {
            warning("Duplicates in mapping")
            warning("Returning DUPLICATED mapping\n")
        } else {
            message("working with unique mapping\n")
        }
    }

    if (type == "region") {
        mapping <- openxlsx2::read_xlsx(file = mapping_file,
                             sheet = "regions")
    }
    if (type == "crops") {
        mapping <- openxlsx2::read_xlsx(path = mapping_file,
                                     sheet = "crops")
    }
    if (!is.null(mapping)) duplicated_message(mapping)
    if (is.null(mapping)) message("No mapping created. Returning NULL.")
    return(mapping)
}
