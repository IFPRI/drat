utils::globalVariables(c("item", "is_any_dup", "j"))
