#' Load and clean the LUH2 states NetCDF
#'
#' Reads the LUH2 `states.nc` file and drops the two layers that are not land
#' use shares (`secma`, secondary mean age, and `secmb`, secondary mean
#' biomass), so that every remaining layer is a `<pool>_<year index>` share
#' between 0 and 1.
#'
#' @param states_nc Path to the LUH2 `states.nc` file.
#'
#' @return A `SpatRaster` with one layer per land use state and year, named
#'   `<state>_<index>` where `<index>` is the 1-based year offset from the
#'   first year of the file (850 for the LUH2 historical release).
#' @seealso [luh2_extract_year()] to convert shares to areas for one year.
#' @family pixel pipeline functions
#' @author Abhijeet Mishra, Claude Code
#' @examples
#' \dontrun{
#' luh <- luh2_load("data/LUH2/states.nc")
#' names(luh)[1:5]
#' }
#' @export
luh2_load <- function(states_nc) {
    luh <- terra::rast(states_nc)
    drop <- grep("secmb|secma", names(luh), value = TRUE)
    luh <- luh[[!names(luh) %in% drop]]
    luh
}
