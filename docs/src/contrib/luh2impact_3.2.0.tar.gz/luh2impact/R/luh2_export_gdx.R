#' Export pixel data and IMPACT totals to GDX
#'
#' Writes every set and parameter the LUMEN GAMS model reads into a single
#' GDX file. This is the last step of the pixel pipeline; the file it writes
#' is what LUMEN is run against.
#'
#' @details
#' Sets written: `pid` (pixels), `cty` (IMPACT countries), `fland` (the five
#' allocated pools `crop`, `natfor`, `past`, `other`, `plant`), `yrs`,
#' `coord`, and the `pid_cty` pixel-to-country map.
#'
#' Parameters written, all areas in 1000 ha:
#' \describe{
#'   \item{`luh2_base(pid,fland)`}{Baseline pixel area per pool.}
#'   \item{`urban_area(pid)`}{Urban area per pixel, held fixed by LUMEN.}
#'   \item{`carea(pid)`}{Cell area.}
#'   \item{`avail_kha(pid)`}{Land available for allocation, excluding urban
#'     land and ice/water.}
#'   \item{`impact_total(cty,fland,yrs)`}{IMPACT control totals that the
#'     pixel allocation must reproduce.}
#'   \item{`pid_coords(pid,coord)`}{Pixel centre coordinates, used to map
#'     the solution back to a raster in [luh2_write_tifs()].}
#'   \item{`w_crop_exp`, `w_crop_con`, `w_natfor_loss`, `w_natfor_gain`,
#'     `w_other_loss`, `w_other_gain`, `w_past`, `w_plant` (all `(pid)`)}{
#'     Allocation weights, each summing to 1 within a country.}
#'   \item{`pa_area(pid)` and `pa_area_cty(cty)`}{WDPA protected area per
#'     pixel and its country total.}
#'   \item{`suit(pid,fland)`}{Historical suitability index, 0 to 1.}
#' }
#' Note that `urban` is written as its own parameter rather than as a member
#' of `fland`, because LUMEN does not reallocate it.
#'
#' @param df A pixel-level data frame returned by [luh2_build_pixels()].
#' @param landx0 A data frame of IMPACT land use results with columns `cty`,
#'   `fland`, `yrs`, `value` (1000 ha) - the same object passed to
#'   [luh2_build_pixels()].
#' @param output_gdx Path to write the output GDX file.
#'
#' @return Invisibly returns `output_gdx`. Called for its side effect of
#'   writing that file.
#' @section Requirements:
#' Needs the `gamstransfer` package, which is shipped with GAMS rather than
#' installed from CRAN.
#' @family pixel pipeline functions
#' @author Abhijeet Mishra, Claude Code
#' @export
luh2_export_gdx <- function(df, landx0, output_gdx) {
    m <- gamstransfer::Container$new()

    # --- Sets ---
    pid_set   <- m$addSet("pid",   records = df$pid,                                         description = "pixel IDs")
    cty_set   <- m$addSet("cty",   records = levels(factor(df$cty)),                         description = "country IDs")
    fland_set <- m$addSet("fland", records = c("crop", "natfor", "past", "other", "plant"),  description = "land pools")
    yrs_set   <- m$addSet("yrs",   records = as.numeric(as.character(unique(landx0$yrs))),   description = "years")
    coord_set <- m$addSet("coord", records = c("x", "y"),                                    description = "coordinates")

    m$addSet("pid_cty", c(pid_set, cty_set),
             records = df[, c("pid", "cty")],
             description = "pixel to country mapping")

    # --- Parameters ---

    # luh2_base: baseline areas by pool
    luh2_base_df <- df |>
        dplyr::select(pid,
                      crop   = crop_area,
                      natfor = natfor_area,
                      past   = past_area,
                      other  = other_area,
                      plant  = plant_area) |>
        tidyr::pivot_longer(-pid, names_to = "fland", values_to = "value")
    luh2_base_df$value[is.na(luh2_base_df$value)] <- 0

    m$addParameter("luh2_base", c(pid_set, fland_set),
                   records = luh2_base_df,
                   description = "LUH2 baseline pixel areas by pool (1000 ha)")

    m$addParameter("urban_area", pid_set,
                   records = df[, c("pid", "urban_area")],
                   description = "fixed urban area per pixel (1000 ha)")

    m$addParameter("carea", pid_set,
                   records = df[, c("pid", "carea_kha")],
                   description = "cell area per pixel (1000 ha)")

    m$addParameter("avail_kha", pid_set,
                   records = df[, c("pid", "avail_kha")],
                   description = "available land per pixel excl. urban and ice/water (1000 ha)")

    # IMPACT control totals
    impact_total_df <- landx0 |>
        dplyr::select(cty, fland, yrs, value) |>
        dplyr::mutate(yrs = as.character(yrs))

    m$addParameter("impact_total", c(cty_set, fland_set, yrs_set),
                   records = impact_total_df,
                   description = "IMPACT control totals by country pool year (1000 ha)")

    # Pixel coordinates
    coords_df <- df |>
        dplyr::select(pid, x, y) |>
        tidyr::pivot_longer(-pid, names_to = "coord", values_to = "value")

    m$addParameter("pid_coords", c(pid_set, coord_set),
                   records = coords_df,
                   description = "pixel centroid coordinates")

    # Weights
    m$addParameter("w_crop_exp", pid_set,
                   records = df[, c("pid", "w_crop_exp")],
                   description = "crop expansion weight per pixel")

    m$addParameter("w_crop_con", pid_set,
                   records = df[, c("pid", "w_crop_con")],
                   description = "crop contraction weight per pixel")

    m$addParameter("w_natfor_loss", pid_set,
                   records = df[, c("pid", "w_natfor_loss")],
                   description = "natural forest loss weight per pixel")

    m$addParameter("w_natfor_gain", pid_set,
                   records = df[, c("pid", "w_natfor_gain")],
                   description = "natural forest gain weight per pixel")

    m$addParameter("w_other_loss", pid_set,
                   records = df[, c("pid", "w_other_loss")],
                   description = "other land loss weight per pixel")

    m$addParameter("w_other_gain", pid_set,
                   records = df[, c("pid", "w_other_gain")],
                   description = "other land gain weight per pixel")

    m$addParameter("w_past", pid_set,
                   records = df[, c("pid", "w_past")],
                   description = "pasture weight per pixel (reserved)")

    m$addParameter("w_plant", pid_set,
                   records = df[, c("pid", "w_plant")],
                   description = "planted forest proximity weight per pixel")

    # Protected area coverage per pixel (000 ha)
    m$addParameter("pa_area", pid_set,
                   records = df[, c("pid", "pa_area")],
                   description = "WDPA protected area coverage per pixel (000 ha)")

    # Protected area coverage aggregated to IMPACT country level (000 ha)
    pa_cty_df <- df |>
        dplyr::group_by(cty) |>
        dplyr::summarise(pa_area = sum(pa_area, na.rm = TRUE)) |>
        dplyr::ungroup()

    m$addParameter("pa_area_cty", cty_set,
                   records = pa_cty_df,
                   description = "WDPA protected area coverage by IMPACT country (000 ha)")

    # suit: suitability index per pixel per pool
    suit_df <- df %>%
        dplyr::select(pid,
                      crop   = suit_crop,
                      natfor = suit_natfor,
                      past   = suit_past,
                      other  = suit_other) %>%
        tidyr::pivot_longer(-pid, names_to = "fland", values_to = "value")

    m$addParameter("suit", c(pid_set, fland_set),
                   records = suit_df,
                   description = "LUH2 historical suitability index per pixel per pool (0-1)")

    m$write(output_gdx)
    invisible(output_gdx)
}
