#' Run the full LUH2-to-GDX pixel pipeline
#'
#' Convenience wrapper that runs every step of the pixel pipeline in order
#' and writes the LUMEN input GDX. Each step is also exported, so the
#' pipeline can be run piece by piece when debugging or when only part of it
#' needs to be redone.
#'
#' @details
#' The steps, in order: [luh2_load()]; [luh2_pool_trend()] three times, for
#' crop, natural forest (primf + primn + secdf) and other land (secdn);
#' [luh2_extract_year()]; [luh2_merge_planted()]; reading `LANDX0` from
#' `impact_gdx` with `DOORMAT::readGDX()`; [luh2_build_pixels()]; and
#' [luh2_export_gdx()]. Progress is reported with messages as it goes.
#'
#' Protected areas are not processed here. Pass an already-rasterized WDPA
#' layer through `pa_tif` if protected area should be carried into LUMEN; see
#' [wdpa_process()] for building one.
#'
#' @param states_nc Path to the LUH2 `states.nc` file.
#' @param static_nc Path to the LUH2 `staticData_quarterdeg.nc` file.
#' @param planted_tif Path to the planted forest GeoTIFF
#'   (e.g. `sdpt_global.tif`).
#' @param cty_shp Path to the IMPACT regions shapefile. Must contain a
#'   `NEW_REGION` field used as the country identifier.
#' @param impact_gdx Path to the IMPACT scenario GDX file, read for its
#'   `LANDX0` land use results.
#' @param output_gdx Path to write the output GDX file.
#' @param year Integer. Target baseline year to extract from LUH2.
#'   Default `2015`.
#' @param year_start Integer. First year of the trend period. Default `1990`.
#' @param year_end Integer. Last year of the trend period. Default `2015`.
#' @param pa_tif Path to a WDPA protected area raster (km^2 per pixel)
#'   produced by [wdpa_process()]. If `NULL` (default), protected area is set
#'   to zero.
#'
#' @return Invisibly returns the path to the written GDX file.
#' @section Requirements:
#' Needs the `gamstransfer` package, which is shipped with GAMS rather than
#' installed from CRAN.
#' @family pixel pipeline functions
#' @author Abhijeet Mishra, Claude Code
#' @examples
#' \dontrun{
#' luh2gdx(
#'     states_nc   = "data/LUH2/states.nc",
#'     static_nc   = "data/LUH2/staticData_quarterdeg.nc",
#'     planted_tif = "data/SDPT/sdpt_global.tif",
#'     cty_shp     = "data/IMPACT/impact_regions.shp",
#'     impact_gdx  = "data/IMPACT/solution.gdx",
#'     output_gdx  = "outputs/lumen_input.gdx",
#'     year        = 2021,
#'     pa_tif      = "data/WDPA/pa_area_km2.tif"
#' )
#' }
#' @importFrom dplyr filter select mutate group_by ungroup summarise left_join across pull starts_with ends_with
#' @importFrom tidyr pivot_wider
#' @export
luh2gdx <- function(states_nc,
                    static_nc,
                    planted_tif,
                    cty_shp,
                    impact_gdx,
                    output_gdx,
                    year = 2015,
                    year_start = 1990,
                    year_end = 2015,
                    pa_tif = NULL) {

    message("Loading LUH2 states...")
    luh <- luh2_load(states_nc)

    message("Computing crop trend (", year_start, "-", year_end, ")...")
    crop_trend <- luh2_pool_trend(luh,
                                  pool_vars  = c("c3ann", "c4ann", "c3per", "c4per", "c3nfx"),
                                  year_start = year_start,
                                  year_end   = year_end)

    message("Computing natural forest trend (", year_start, "-", year_end, ")...")
    natfor_trend <- luh2_pool_trend(luh,
                                    pool_vars  = c("primf", "primn", "secdf"),
                                    year_start = year_start,
                                    year_end   = year_end)

    message("Computing other land trend (", year_start, "-", year_end, ")...")
    other_trend <- luh2_pool_trend(luh,
                                   pool_vars  = c("secdn"),
                                   year_start = year_start,
                                   year_end   = year_end)

    message("Extracting year ", year, "...")
    extracted <- luh2_extract_year(luh, static_nc, year)

    message("Merging planted forest...")
    shares <- luh2_merge_planted(luarea = extracted$luarea,
                                 cellarea = extracted$cellarea,
                                 planted_tif = planted_tif,
                                 fstnf = extracted$fstnf,
                                 cty_shp = cty_shp)

    message("Reading IMPACT land use data...")
    landx0 <- DOORMAT::readGDX(gdx = impact_gdx, name = "LANDX0", quick_df = TRUE)$data

    message("Building pixel data frame...")
    df <- luh2_build_pixels(
        luh          = luh,
        shares       = shares,
        crop_trend   = crop_trend,
        natfor_trend = natfor_trend,
        other_trend  = other_trend,
        cellarea     = extracted$cellarea,
        icwtr        = extracted$icwtr,
        cty_shp      = cty_shp,
        landx0       = landx0,
        pa_tif       = pa_tif
    )

    message("Exporting GDX to ", output_gdx, "...")
    luh2_export_gdx(df, landx0, output_gdx)

    message("Done.")
    invisible(output_gdx)
}
