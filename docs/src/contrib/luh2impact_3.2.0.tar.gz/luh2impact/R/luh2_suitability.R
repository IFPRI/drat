#' Calculate a land use suitability index from LUH2 historical data
#'
#' Computes a suitability index for each land pool by averaging historical
#' land use shares over a long time window. Pixels that have held a high
#' share of a given land type over centuries are treated as more suitable for
#' that land type in future projections, and the index is used to weight
#' reallocation in [luh2_build_pixels()] and exported to LUMEN as `suit`.
#'
#' @param luh A `SpatRaster` returned by [luh2_load()].
#' @param year_start Integer. Start year of the suitability window.
#'   Default `1715`.
#' @param year_end Integer. End year of the suitability window.
#'   Default `2015`.
#' @param subsample Integer. Step between the years actually read, to keep
#'   the computation tractable. Default `10` (every 10th year).
#'
#' @return A four-layer `SpatRaster`: `suit_crop`, `suit_natfor`,
#'   `suit_past`, `suit_other`. Values run from 0 to 1 and are the mean share
#'   of each pool over the sampled years.
#'
#' @details
#' Land pool definitions follow the LUH2 variable groupings:
#' \itemize{
#'   \item `crop`: c3ann, c4ann, c3per, c4per, c3nfx
#'   \item `natfor`: primf, secdf
#'   \item `past`: pastr, range
#'   \item `other`: primn, secdn
#' }
#' Within each year, variables are summed across pool members before
#' averaging across years. `plant` and `urban` get no suitability layer:
#' planted forest is placed by proximity instead (see [luh2_build_pixels()]),
#' and urban land is held fixed.
#'
#' Unlike the other pixel functions, layer indices are derived from the
#' hard-coded LUH2 historical epoch (`index = year - 849`) rather than from
#' `terra::time(luh)`, so `year_start` and `year_end` must refer to a LUH2
#' file that starts in 850.
#'
#' @family pixel pipeline functions
#' @author Abhijeet Mishra, Claude Code
#' @examples
#' \dontrun{
#' luh  <- luh2_load("data/LUH2/states.nc")
#' suit <- luh2_suitability(luh, year_start = 1700, year_end = 2015)
#' terra::plot(suit)
#' }
#'
#' @export
luh2_suitability <- function(luh, year_start = 1715, year_end = 2015, subsample = 10) {

    pools <- list(
        crop   = c("c3ann", "c4ann", "c3per", "c4per", "c3nfx"),
        natfor = c("primf", "secdf"),
        past   = c("pastr", "range"),
        other  = c("primn", "secdn")
    )

    # LUH2 layer index = year - 849
    idx_subsample <- seq(year_start - 849, year_end - 849, by = subsample)

    suit <- terra::rast(lapply(names(pools), function(pool) {

        vars <- pools[[pool]]

        pool_layers <- terra::rast(lapply(idx_subsample, function(i) {
            pattern <- paste0("^(", paste(vars, collapse = "|"), ")_", i, "$")
            idx <- grep(pattern, names(luh))
            terra::app(luh[[idx]], sum, na.rm = TRUE)
        }))

        r <- terra::mean(pool_layers, na.rm = TRUE)
        names(r) <- paste0("suit_", pool)
        message("Done: ", pool)
        r
    }))

    suit
}
