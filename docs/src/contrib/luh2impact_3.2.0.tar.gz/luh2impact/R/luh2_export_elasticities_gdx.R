#' Export land use elasticities and baseline areas to GDX
#'
#' Writes the fitted elasticities, their diagnostics, baseline FAOSTAT land
#' areas and the optional protected area and biodiversity parameters into a
#' single GDX file for the IMPACT land use module.
#'
#' @details
#' Parameters written:
#' \describe{
#'   \item{`LANDELAS(cty,land_use,driver)`}{Elasticities used by the model:
#'     `ok`-flagged rows only.}
#'   \item{`LANDELAS_RAW_ELAST`, `LANDELAS_RAW_SE`, `LANDELAS_RAW_PVAL`}{The
#'     same estimates, standard errors and p-values for every row including
#'     the flagged ones, kept for diagnostics.}
#'   \item{`LANDELAS_RAW_NOBS(cty,land_use)`}{Observation count behind each
#'     regression.}
#'   \item{`LAND00(cty,item)`}{Baseline land area in 1000 ha for `base_year`,
#'     covering `crop`, `natfor`, `other`, `past` and `plant`, plus anything
#'     passed through `extra_land00`.}
#'   \item{`LANDPA00(cty)`}{Written only when `pa00` is supplied: the
#'     aggregate protected area floor in 1000 ha.}
#'   \item{`BII_COEFF(cty,fland)`}{Written only when `bii_coeff` is supplied:
#'     the biodiversity intactness coefficient per pool, 0 to 1.}
#' }
#' The `driver` index of the elasticity parameters takes the values `crop`
#' and `gdppc`.
#'
#' @param results The `results` data frame from [luh2_fit_elasticities()].
#' @param faoland A data frame returned by [luh2_load_faoland()], used for
#'   the baseline land areas in `base_year`.
#' @param output_gdx Path to write the output GDX file.
#' @param base_year Integer. Year used for the `LAND00` baseline.
#'   Default `2021`.
#' @param extra_land00 Optional data frame with columns `cty`, `item`,
#'   `value` appended to `LAND00` as additional baseline pools that are
#'   genuinely distinct land covers (e.g. `item = "urban"` from
#'   [luh2_urban_area_cty()]). These pools get no `LANDELAS` entry - they
#'   are fixed stocks, not fitted against cropland and income. Protected
#'   area does not belong here: it is not a distinct cover, it overlays
#'   `natfor`, `past` and `other`, so it goes through `pa00` instead.
#'   Default `NULL`.
#' @param pa00 Optional data frame with columns `cty` and `value` (aggregate
#'   protected non-crop land area in 1000 ha), e.g. from
#'   [luh2_pa_area_cty()]. Written as `LANDPA00(cty)`, a floor on protected
#'   land rather than a `LAND00` pool. Default `NULL`.
#' @param bii_coeff Optional data frame with columns `cty`, `fland` and
#'   `value` (0 to 1), e.g. from [luh2_bii_coeff_cty()] or
#'   [luh2_bii_coeff_cty_pixel()]. Written as `BII_COEFF(cty,fland)`.
#'   Default `NULL`.
#' @param author Character. Recorded in the GDX as provenance. Defaults to
#'   the OS user running the session (`Sys.info()[["user"]]`) rather than the
#'   package maintainer, since the point is to record who generated this
#'   particular file once it is version controlled and several people can
#'   run the pipeline.
#'
#' @return Invisibly returns `output_gdx`. Called for its side effect of
#'   writing that file. The GDX also carries a `gdx_metadata` set with
#'   `author=...`, `created_at=...` (local timestamp) and `package=...`
#'   (installed `luh2impact` version); GDX has no file-level metadata, so
#'   this is stored as a small set whose elements carry the text.
#' @section Requirements:
#' Needs the `gamstransfer` package, which is shipped with GAMS rather than
#' installed from CRAN.
#' @family country pipeline functions
#' @author Abhijeet Mishra, Claude Code
#' @examples
#' \dontrun{
#' fit <- luh2_fit_elasticities(faoland, gdppc)
#' luh2_export_elasticities_gdx(fit$results, faoland, "outputs/landuse.gdx",
#'                              base_year = 2021)
#' }
#' @export
luh2_export_elasticities_gdx <- function(results, faoland, output_gdx, base_year = 2021,
                                         extra_land00 = NULL, pa00 = NULL, bii_coeff = NULL,
                                         author = NULL) {
    if (is.null(author)) {
        author <- tryCatch(Sys.info()[["user"]], error = function(e) NA_character_)
        if (is.na(author) || !nzchar(author)) author <- "unknown"
    }
    pkg_version <- tryCatch(as.character(utils::packageVersion("luh2impact")),
                            error = function(e) "unknown")
    land00 <- faoland[faoland$year == base_year & faoland$item %in% c("crop", "natfor", "other", "past", "plant"),
                      c("cty", "item", "value")]
    land00$item <- as.character(land00$item)

    if (!is.null(extra_land00)) {
        land00 <- rbind(land00, extra_land00[, c("cty", "item", "value")])
    }

    raw_long <- results |>
        tidyr::pivot_longer(
            cols = c(elast_crop, se_crop, pval_crop, elast_gdppc, se_gdppc, pval_gdppc),
            names_to = c(".value", "driver"),
            names_pattern = "^(elast|se|pval)_(crop|gdppc)$"
        ) |>
        dplyr::rename(elasticity = elast)

    landelas_long <- raw_long |>
        dplyr::filter(flag == "ok", !is.na(elasticity)) |>
        dplyr::select(cty, land_use, driver, elasticity)

    m <- gamstransfer::Container$new()

    add_stat <- function(stat_col, param_name, desc) {
        m$addParameter(
            name = param_name,
            domain = list("*", "*", "*"),
            records = raw_long |>
                dplyr::select(cty, land_use, driver, value = dplyr::all_of(stat_col)) |>
                dplyr::filter(!is.na(value)) |>
                as.data.frame(),
            description = desc
        )
    }

    add_stat("elasticity", "LANDELAS_RAW_ELAST", "Elasticity estimates, all flags")
    add_stat("se",         "LANDELAS_RAW_SE",    "Standard errors, all flags")
    add_stat("pval",       "LANDELAS_RAW_PVAL",  "P-values, all flags")

    m$addParameter(
        name = "LANDELAS_RAW_NOBS",
        domain = list("*", "*"),
        records = results |> dplyr::select(cty, land_use, n_obs) |> dplyr::distinct() |> as.data.frame(),
        description = "Observation count per country x land use"
    )

    m$addParameter(
        name = "LANDELAS",
        domain = list("*", "*", "*"),
        records = as.data.frame(landelas_long),
        description = "Land-use elasticities wrt cropland and gdppc, ok-flagged only"
    )

    m$addParameter(
        name = "LAND00",
        domain = list("*", "*"),
        records = as.data.frame(land00),
        description = "Initial FAOSTAT land"
    )

    if (!is.null(pa00)) {
        m$addParameter(
            name = "LANDPA00",
            domain = list("*"),
            records = as.data.frame(pa00[, c("cty", "value")]),
            description = "Protected non-crop land area, aggregate floor (1000 ha)"
        )
    }

    if (!is.null(bii_coeff)) {
        m$addParameter(
            name = "BII_COEFF",
            domain = list("*", "*"),
            records = as.data.frame(bii_coeff[, c("cty", "fland", "value")]),
            description = "BII coefficient per country per land pool (0-1)"
        )
    }

    m$addSet(
        "gdx_metadata",
        records = c(
            paste0("author=", author),
            paste0("created_at=", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
            paste0("package=luh2impact ", pkg_version)
        ),
        description = "Provenance metadata for this GDX file"
    )

    m$write(output_gdx)
    invisible(output_gdx)
}
