#' Compute per-country BII coefficients per land pool from pixel imagery
#'
#' Reads a pre-computed pixel-derived `BII_COEFF(cty,fland)` table, built
#' from Nguyen's 2020 land use and biodiversity intactness rasters, as an
#' alternative to the literature-based [luh2_bii_coeff_cty()]. Unlike that
#' function, every pool (`crop`, `urban`, `past`, `plant`, `natfor`,
#' `other`) gets a country-specific value taken from imagery, not just
#' `natfor`.
#'
#' @details
#' The default table is built from Nguyen's `Landuse_Fraction` rasters
#' (0.02 degree fractional coverage per class: agro, crop, past, prim, secd,
#' urbn), which are pixel-for-pixel co-registered with the BII raster
#' (identical size, pixel size, origin and extent), so each pool's
#' coefficient is a fraction-weighted mean BII score. It superseded an
#' earlier table built from the raw 500 m High-Resolution Harmonized Land
#' Use (HHLU) raster through a custom cross-resolution alignment; the two
#' were cross-checked and agree to correlations above 0.9999 on every pool,
#' with a maximum absolute difference under 0.008, so the fraction-based
#' version was kept as the faster and better-aligned path. Both tables ship
#' with the package and either can be passed to `pixel_csv`.
#'
#' `natfor` and `other` cannot be separated from this pixel data alone:
#' Nguyen's primary and secondary vegetation classes are organized by
#' successional and management-intensity stage rather than by cover type
#' (primary vegetation is any low-disturbance land, whether forest,
#' grassland, desert or tundra, and secondary vegetation mixes regenerating
#' natural forest with commercial timber plantations), and no grouping of
#' the raw HHLU classes tracked this package's FAOSTAT-derived natfor/other
#' area split well - the best of six groupings correlated at about 0.35.
#' Instead, the combined natural-land score is split back into the two pools
#' assuming `other_coeff = 0.90 * natfor_coeff`, solved per country so that
#' the `LAND00`-area-weighted average of the two still reproduces the
#' observed combined value. Where `other` area vastly exceeds `natfor` area
#' (the arid countries DZA, GRL, LBY, MLI, MRT, NER and TCD), that algebra
#' would push `natfor` above the physical ceiling of 1.0; those seven have
#' `natfor` capped at 1.0 and `other` re-solved from the mass balance alone,
#' which the `natfor_capped` column of the CSV flags.
#'
#' Two caveats on how far these numbers can be pushed. Nguyen's fitted BII
#' model retained only primary vegetation, cropland and urban fractions as
#' significant land use predictors, alongside human-impact covariates
#' (roads, population density, travel time, geographic distance); pasture
#' and agroforestry fractions did not survive variable selection. So `past`
#' and `plant` here are real values read off the predicted BII surface at
#' those locations, but their variation comes from the surrounding primary,
#' cropland and urban composition and the human-footprint covariates rather
#' than from a pasture or agroforestry effect of their own. `crop` and
#' `urban` rest on directly fitted effects and are the most solid of the six
#' pools. And a handful of countries have no pixels at all for `past` (one
#' country) or `plant` (three); those rows are dropped rather than returned
#' as `NA`, matching the way `LAND00` simply omits a pool a country does not
#' have.
#'
#' @section CSV format:
#' Both shipped tables have one row per IMPACT country, a `cty` column, a
#' `bii_<pool>` column per pool, the `natfor` and `other` areas used in the
#' mass-balance split, and the `natfor_capped` flag. The fraction-based
#' table additionally carries `wsum_*` (summed class fractions) and the
#' intermediate `bii_prim`, `bii_secd` and `bii_natural_combined` columns;
#' the HHLU-based one carries `n_*` pixel counts instead. Only `cty` and the
#' six `bii_<pool>` columns are read by this function. The scripts that
#' build these tables from the raw rasters are not part of the package.
#'
#' @param pixel_csv Path to the pixel-derived BII coefficient CSV. Defaults
#'   to the fraction-based table shipped with the package. Pass
#'   `system.file("extdata", "pixel_bii_coeff_r090.csv", package = "luh2impact")`
#'   to use the original HHLU-based one instead.
#'
#' @return A data frame with columns `cty`, `fland` and `value` (BII
#'   coefficient, 0 to 1), one row per country and pool with data - the same
#'   shape as [luh2_bii_coeff_cty()]'s output, ready to pass as the
#'   `bii_coeff` argument of [luh2_export_elasticities_gdx()].
#' @seealso [luh2_bii_coeff_cty()] for the literature-based alternative.
#' @family country pipeline functions
#' @author Abhijeet Mishra, Claude Code
#' @examples
#' bii <- luh2_bii_coeff_cty_pixel()
#' head(bii)
#' @export
luh2_bii_coeff_cty_pixel <- function(pixel_csv = system.file("extdata", "pixel_bii_coeff_fraction_r090.csv",
                                                              package = "luh2impact")) {
    raw <- utils::read.csv(pixel_csv, stringsAsFactors = FALSE)

    pool_cols <- c(crop = "bii_crop", urban = "bii_urban", past = "bii_past",
                   plant = "bii_plant", natfor = "bii_natfor", other = "bii_other")

    out <- do.call(rbind, lapply(names(pool_cols), function(fl) {
        data.frame(cty = raw$cty, fland = fl, value = raw[[pool_cols[[fl]]]])
    }))
    out[!is.na(out$value), ]
}
