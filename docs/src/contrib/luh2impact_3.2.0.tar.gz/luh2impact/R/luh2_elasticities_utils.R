# Internal helpers shared by luh2_load_faoland(), luh2_compute_gdppc(),
# luh2_fit_elasticities() and luh2_natfor_primary_share_cty(). Not exported.

#' Read the FAO-to-IMPACT country mapping from the IMPACT sets workbook
#'
#' @param sets_xlsx Path to the IMPACT `Sets.xlsx` workbook.
#' @return A data frame with columns `fcty` (FAO country code) and `cty`
#'   (IMPACT region), read from the `Regions` sheet starting at column 5,
#'   row 4, with unmapped rows dropped.
#' @noRd
.luh2_read_ctyset <- function(sets_xlsx) {
    ctyset <- openxlsx2::read_xlsx(file = sets_xlsx, sheet = "Regions",
                                   start_col = 5, start_row = 4)[, 1:2]
    ctyset <- ctyset[!is.na(ctyset$FCTY), ]
    names(ctyset) <- tolower(names(ctyset))
    ctyset$fcty <- as.numeric(ctyset$fcty)
    ctyset
}

#' Linearly interpolate interior NAs
#'
#' Mirrors `zoo::na.approx(x, na.rm = FALSE)` without taking the dependency:
#' interior gaps are filled, leading and trailing NAs are left untouched, and
#' a vector with fewer than two non-missing values is returned unchanged.
#'
#' @param x Numeric vector.
#' @return `x` with interior NAs interpolated.
#' @noRd
.luh2_approx_na <- function(x) {
    idx <- seq_along(x)
    ok  <- !is.na(x)
    if (sum(ok) < 2) return(x)
    x[!ok] <- stats::approx(idx[ok], x[ok], xout = idx[!ok])$y
    x
}

#' Pull one statistic for one term out of a regression coefficient table
#'
#' @param coef_tbl The `coefficients` matrix from [summary.lm()].
#' @param term Row name to look up, e.g. `"dln_crop"`.
#' @param stat Column name to look up, e.g. `"Estimate"`.
#' @param default Value returned when `term` is absent, which happens when a
#'   term is dropped for collinearity. Default `NA_real_`.
#' @return A single numeric value.
#' @noRd
.luh2_safe_coef <- function(coef_tbl, term, stat, default = NA_real_) {
    if (term %in% rownames(coef_tbl)) coef_tbl[term, stat] else default
}
