#' Compute the FAOSTAT-native primary-forest share of the `natfor` pool
#'
#' For each IMPACT country, computes the share of `natfor` (naturally
#' regenerating forest) that is primary forest, using items already present
#' in the FAOSTAT bulk land use file - no LUH2 data needed. It follows the
#' FAO/FRA definitional hierarchy: naturally regenerating forest is primary
#' forest plus other naturally regenerated ("secondary") forest, so
#' secondary forest is `Naturally regenerating forest - Primary Forest`.
#'
#' @details
#' The output is a share, not an area, and is meant to be used as a blending
#' weight against `natfor`'s existing FAOSTAT total (as
#' [luh2_bii_coeff_cty()] does), not as a substitute for it.
#'
#' The shares were spot-checked against countries with known large tracts of
#' intact forest (Brazil, Canada, DR Congo, Indonesia, Russia) and come out
#' high relative to a global median near 1 percent, which is consistent with
#' where intact forest actually remains.
#'
#' Equivalent splits for `past`, `other` and `crop` were tried and dropped:
#' FAOSTAT's pasture sub-items are unpopulated for most countries, and
#' LUH2's primary/secondary non-forest classification did not give a
#' trustworthy signal for `other` (Saudi Arabia, for instance, came out with
#' a near-zero primary share for desert land that has never been converted).
#' This function stays deliberately narrow to the one split that was
#' validated.
#'
#' @param fao_land_csv Path to the FAOSTAT
#'   `Inputs_LandUse_E_All_Data_(Normalized).csv` file.
#' @param sets_xlsx Path to the IMPACT `Sets.xlsx` workbook
#'   (see [luh2_load_faoland()]).
#' @param year Integer. Year to compute the share for. Default `2021`.
#'
#' @return A data frame with columns:
#' \describe{
#'   \item{`cty`}{IMPACT country code.}
#'   \item{`natfor_primary_share`}{Share of `natfor` that is primary forest,
#'     0 to 1, or `NA` where no naturally regenerating forest is reported.}
#'   \item{`flag_natfor`}{`"ok"`, or `"primary_exceeds_natregen"` where
#'     `Primary Forest` exceeds `Naturally regenerating forest` - a FAOSTAT
#'     inconsistency, in which case the share is clipped to 1.}
#' }
#' @family country pipeline functions
#' @author Abhijeet Mishra, Claude Code
#' @examples
#' \dontrun{
#' shares <- luh2_natfor_primary_share_cty(
#'     "data/FAOSTAT/Inputs_LandUse_E_All_Data_(Normalized).csv",
#'     "data/IMPACT/Sets.xlsx"
#' )
#' summary(shares$natfor_primary_share)
#' }
#' @export
luh2_natfor_primary_share_cty <- function(fao_land_csv, sets_xlsx, year = 2021) {
    items_needed <- c("Primary Forest", "Naturally regenerating forest")

    raw <- as.data.frame(data.table::fread(file = fao_land_csv, header = TRUE))
    names(raw) <- tolower(names(raw))

    raw <- raw[raw$unit %in% "1000 ha" & raw$item %in% items_needed & raw$year == year,
              c("area code", "item", "value")]
    names(raw)[1] <- "fcty"
    raw$fcty <- as.numeric(raw$fcty)

    ctyset <- .luh2_read_ctyset(sets_xlsx)
    raw <- dplyr::left_join(raw, ctyset, by = "fcty")
    raw <- raw[!is.na(raw$cty), ]

    agg <- raw |>
        dplyr::group_by(cty, item) |>
        dplyr::summarise(value = sum(value, na.rm = TRUE), .groups = "drop") |>
        tidyr::pivot_wider(names_from = item, values_from = value, values_fill = 0)

    for (col in items_needed) if (!col %in% names(agg)) agg[[col]] <- 0

    agg$flag_natfor <- ifelse(agg[["Primary Forest"]] > agg[["Naturally regenerating forest"]] + 1e-6,
                              "primary_exceeds_natregen", "ok")
    agg$natfor_primary_share <- ifelse(agg[["Naturally regenerating forest"]] > 0,
                                       agg[["Primary Forest"]] / agg[["Naturally regenerating forest"]], NA_real_)
    agg$natfor_primary_share <- pmin(pmax(agg$natfor_primary_share, 0), 1)

    as.data.frame(agg[, c("cty", "natfor_primary_share", "flag_natfor")])
}
