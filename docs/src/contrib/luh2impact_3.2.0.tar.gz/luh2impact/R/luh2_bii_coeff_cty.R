#' Compute per-country BII coefficients per land pool from the literature
#'
#' Blends the FAOSTAT-derived primary-forest share from
#' [luh2_natfor_primary_share_cty()] with primary and secondary forest
#' biodiversity intactness coefficients from Leclere et al. (2018), Figure 3,
#' so that `natfor` gets a country-specific coefficient instead of one flat
#' global value. The other pools (`crop`, `past`, `other`, `plant`, `urban`)
#' keep the flat coefficients already used in the LUMEN pixel implementation
#' (`bii_coeff` in `lumen.gms`), because no validated country-level split
#' exists for them yet - see [luh2_natfor_primary_share_cty()] for what was
#' tried and abandoned.
#'
#' @details
#' The idea behind the blend is that BII compares current abundance against
#' the same ecosystem's own undisturbed state, so a country whose remaining
#' natural forest is largely primary should not score the same as one whose
#' forest is largely regrowth. Only `natfor` is treated this way here.
#'
#' Two defaults are approximate and worth revisiting if better numbers turn
#' up. `bii_secondary_forested` (`0.85`) is read visually off Figure 3's
#' forested-panel secondary-vegetation bars, excluding Timber, which maps to
#' `plant` rather than `natfor`. `bii_urban` (`0.65`) is likewise a visual
#' read of the Urban bars; `lumen.gms` offers no precedent for it, since
#' urban land is held fixed there and never enters the pixel BII
#' calculation. Neither value has been digitized from the source figure.
#'
#' Countries with no reported naturally regenerating forest (so
#' `natfor_primary_share` is `NA`) fall back to the midpoint of
#' `bii_primary_forested` and `bii_secondary_forested`, rather than being
#' dropped or assumed to be all primary or all secondary.
#'
#' @references
#' Leclere, D. et al. (2018). Towards pathways bending the curve of
#' terrestrial biodiversity trends within the 21st century. IIASA.
#'
#' @param fao_land_csv Path to the FAOSTAT
#'   `Inputs_LandUse_E_All_Data_(Normalized).csv` file.
#' @param sets_xlsx Path to the IMPACT `Sets.xlsx` workbook
#'   (see [luh2_load_faoland()]).
#' @param year Integer. Year used for the `natfor` primary-forest share.
#'   Default `2021`.
#' @param bii_primary_forested Numeric. BII coefficient for primary forest.
#'   Default `1.0`.
#' @param bii_secondary_forested Numeric. BII coefficient for secondary
#'   forest (approximate, see Details). Default `0.85`.
#' @param bii_other,bii_past,bii_plant,bii_crop Numeric. Flat BII
#'   coefficients matching the existing `bii_coeff` table in `lumen.gms`.
#'   Defaults `0.888`, `0.791`, `0.672`, `0.576`.
#' @param bii_urban Numeric. Flat BII coefficient for urban land
#'   (approximate, see Details). Default `0.65`.
#'
#' @return A data frame with columns `cty`, `fland` and `value` (BII
#'   coefficient, 0 to 1), one row per country and pool, ready to pass as the
#'   `bii_coeff` argument of [luh2_export_elasticities_gdx()].
#' @seealso [luh2_bii_coeff_cty_pixel()] for the imagery-derived
#'   alternative, which varies by country for every pool.
#' @family country pipeline functions
#' @author Abhijeet Mishra, Claude Code
#' @examples
#' \dontrun{
#' bii <- luh2_bii_coeff_cty(
#'     "data/FAOSTAT/Inputs_LandUse_E_All_Data_(Normalized).csv",
#'     "data/IMPACT/Sets.xlsx"
#' )
#' }
#' @export
luh2_bii_coeff_cty <- function(fao_land_csv, sets_xlsx, year = 2021,
                               bii_primary_forested = 1.0, bii_secondary_forested = 0.85,
                               bii_other = 0.888, bii_past = 0.791, bii_plant = 0.672,
                               bii_crop = 0.576, bii_urban = 0.65) {
    shares <- luh2_natfor_primary_share_cty(fao_land_csv, sets_xlsx, year = year)

    natfor_coeff <- shares |>
        dplyr::mutate(
            fland = "natfor",
            value = ifelse(is.na(natfor_primary_share),
                           (bii_primary_forested + bii_secondary_forested) / 2,
                           natfor_primary_share * bii_primary_forested +
                               (1 - natfor_primary_share) * bii_secondary_forested)
        ) |>
        dplyr::select(cty, fland, value)

    flat_pools <- data.frame(
        fland = c("other", "past", "plant", "crop", "urban"),
        value = c(bii_other, bii_past, bii_plant, bii_crop, bii_urban)
    )
    flat_coeff <- do.call(rbind, lapply(unique(shares$cty), function(c) {
        data.frame(cty = c, fland = flat_pools$fland, value = flat_pools$value)
    }))

    rbind(as.data.frame(natfor_coeff), flat_coeff)
}
