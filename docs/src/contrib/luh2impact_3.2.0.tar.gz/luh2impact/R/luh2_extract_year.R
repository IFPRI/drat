#' Extract land use areas for a target year
#'
#' Subsets the LUH2 raster to a single year, multiplies the shares by cell
#' area to get areas, and returns them together with the static grid layers
#' (cell area, ice/water fraction, country code, forest/non-forest flag) that
#' the rest of the pixel pipeline needs.
#'
#' @details
#' LUH2 layers are named `<state>_<index>`, where `<index>` counts years from
#' the first year in the file. The index for `year` is derived from
#' `terra::time(luh)[1]`, so the function works for any LUH2 release as long
#' as the time axis is set. An error is thrown if the requested year is not
#' in the file.
#'
#' @param luh A `SpatRaster` returned by [luh2_load()].
#' @param static_nc Path to the LUH2 `staticData_quarterdeg.nc` file.
#' @param year Integer. Target year (e.g. 2015).
#'
#' @return A named list of `SpatRaster` objects:
#' \describe{
#'   \item{`luarea`}{Land use areas in km^2, one layer per LUH2 state, for
#'     `year` only (layer names have the year suffix stripped).}
#'   \item{`cellarea`}{Single layer. Grid cell area in km^2 (`carea`).}
#'   \item{`icwtr`}{Single layer. Ice and water fraction of the cell
#'     (`icwtr`), between 0 and 1.}
#'   \item{`ccode`}{Single layer. LUH2 country code per cell (`ccode`); 0
#'     over ocean.}
#'   \item{`fstnf`}{Single layer. Forest/non-forest flag (`fstnf`), 1 where
#'     the potential vegetation is forest, used to split natural land into
#'     `natfor` and `other` in [luh2_merge_planted()].}
#' }
#' @family pixel pipeline functions
#' @author Abhijeet Mishra, Claude Code
#' @examples
#' \dontrun{
#' luh <- luh2_load("data/LUH2/states.nc")
#' extracted <- luh2_extract_year(luh, "data/LUH2/staticData_quarterdeg.nc", year = 2015)
#' extracted$luarea
#' }
#' @export
luh2_extract_year <- function(luh, static_nc, year) {
    luh_start <- as.integer(terra::time(luh)[1])
    suffix    <- year - luh_start + 1

    year_layers <- grep(paste0("_", suffix, "$"), names(luh), value = TRUE)
    if (length(year_layers) == 0) {
        stop("Year ", year, " (suffix _", suffix, ") not found in LUH2 raster.")
    }

    luh_yr <- luh[[year_layers]]
    names(luh_yr) <- gsub("_\\d+$", "", names(luh_yr))

    static <- terra::rast(static_nc)
    cellarea <- static[["carea"]]
    icwtr    <- static[["icwtr"]]
    ccode    <- static[["ccode"]]
    fstnf    <- static[["fstnf"]]

    luarea <- luh_yr * cellarea

    list(
        luarea   = luarea,
        cellarea = cellarea,
        icwtr    = icwtr,
        ccode    = ccode,
        fstnf    = fstnf
    )
}
