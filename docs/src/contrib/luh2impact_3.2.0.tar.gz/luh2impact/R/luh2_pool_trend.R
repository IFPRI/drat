#' Compute the per-pixel linear trend for a land use pool
#'
#' Sums the requested LUH2 layers for each year in the period and fits a
#' per-pixel linear trend, returning the slope (change in share per year).
#' The slope is computed analytically from the centred time index rather than
#' by fitting a model per pixel, which is what makes this usable over the
#' whole 0.25 degree grid.
#'
#' @param luh A `SpatRaster` returned by [luh2_load()].
#' @param pool_vars Character vector of LUH2 layer name prefixes to sum
#'   (e.g. `c("c3ann", "c4ann", "c3per", "c4per", "c3nfx")` for crop,
#'   `c("primf", "primn", "secdf")` for natural forest,
#'   `c("secdn")` for other land).
#' @param year_start Integer. First year of the trend period (e.g. 1990).
#' @param year_end Integer. Last year of the trend period (e.g. 2015).
#'
#' @return A single-layer `SpatRaster` named `"pool_slope"`, in share per
#'   year. Positive values mean the pool expanded over the period. Pixels
#'   that are `NA` in every year stay `NA`.
#' @family pixel pipeline functions
#' @author Abhijeet Mishra, Claude Code
#' @examples
#' \dontrun{
#' luh <- luh2_load("data/LUH2/states.nc")
#' natfor_slope <- luh2_pool_trend(luh,
#'                                 pool_vars  = c("primf", "primn", "secdf"),
#'                                 year_start = 1990,
#'                                 year_end   = 2015)
#' }
#' @export
luh2_pool_trend <- function(luh, pool_vars, year_start, year_end) {
    # nolint start: commented_code_linter
    luh_start <- as.integer(terra::time(luh)[1])

    suffix_start <- year_start - luh_start + 1
    suffix_end   <- year_end   - luh_start + 1
    suffixes     <- seq(suffix_start, suffix_end)

    pool_stack <- terra::rast(lapply(suffixes, function(s) {
        layers    <- paste0(pool_vars, "_", s)
        available <- layers[layers %in% names(luh)]
        if (length(available) == 0) stop("No layers found for suffix ", s,
                                         " (pool_vars: ", paste(pool_vars, collapse = ", "), ")")
        terra::app(luh[[available]], fun = "sum", na.rm = TRUE)
    }))

    time_idx <- seq_along(suffixes) # nolint: object_usage_linter

    # Pre-compute OLS slope analytically - no lm needed
    t_centered <- time_idx - mean(time_idx)
    t_ss <- sum(t_centered^2)

    pool_trend <- terra::app(pool_stack, function(x) {
        if (all(is.na(x))) return(NA_real_)
        sum(t_centered * x, na.rm = TRUE) / t_ss
    })

    # pool_trend <- terra::app(pool_stack, function(x) {
    #     if (all(is.na(x))) return(NA_real_)
    #     stats::coef(stats::lm(x ~ time_idx))[2]
    # })

    names(pool_trend) <- "pool_slope"
    pool_trend
    # nolint end
}
