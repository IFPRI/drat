#' Write GeoTIFFs from a LUMEN solution GDX
#'
#' Reads the solved pixel land use (`lu_out`) from a LUMEN solution GDX and
#' writes one multi-layer GeoTIFF per land pool, with one layer per solution
#' year. Files are named `lu_<pool>.tif` and written into `output_dir`.
#'
#' @details
#' Rasters are built directly from the pixel coordinates stored in the GDX
#' (`pid_coords`) and then resampled onto the standard 0.25 degree LUH2 grid
#' with nearest-neighbour, which keeps the output aligned with the model
#' inputs and avoids the `NA` holes that come from snapping points to a grid.
#' One file is written for each of `crop`, `natfor`, `past`, `other` and
#' `plant`; urban land is fixed in LUMEN and is not part of the solution.
#'
#' @param gdx_path Path to the LUMEN solution GDX file
#'   (e.g. `"outputs/CHM/solution_lu.gdx"`).
#' @param output_dir Path to an existing directory where the GeoTIFFs are
#'   written. Existing files of the same name are overwritten.
#'
#' @return Invisibly, a named list of the `SpatRaster` objects written, one
#'   per pool, each with one layer per year named by the year.
#' @section Requirements:
#' Needs the `gamstransfer` package, which is shipped with GAMS rather than
#' installed from CRAN.
#' @seealso [luh2_plot_results()] and [luh2_plot_bii()], which read the same
#'   outputs for plotting.
#' @family output functions
#' @author Abhijeet Mishra, Claude Code
#' @examples
#' \dontrun{
#' luh2_write_tifs("outputs/CHM/solution_lu.gdx", "outputs/CHM")
#' }
#' @export
luh2_write_tifs <- function(gdx_path, output_dir) {
    m_out <- gamstransfer::Container$new(gdx_path)

    lu_out <- m_out$getSymbols("lu_out")[[1]]$records

    pid_coords <- m_out["pid_coords"]$records |>
        tidyr::pivot_wider(names_from = "coord", values_from = "value")

    lu_out <- lu_out |>
        dplyr::left_join(pid_coords[, c("pid", "x", "y")], by = "pid")

    template <- terra::rast(
        resolution = 0.25,
        extent     = terra::ext(-180, 180, -90, 90),
        crs        = "OGC:CRS84"
    )

    pools   <- c("crop", "natfor", "past", "other", "plant")
    yrs_seq <- as.character(sort(unique(lu_out$yrs)))

    result <- list()

    for (pool in pools) {
        pool_stack <- terra::rast(lapply(yrs_seq, function(yr) {
            sub <- lu_out |>
                dplyr::filter(fland == pool, yrs == yr) |>
                dplyr::select(x, y, value)

            # Build raster directly from xyz coordinates - avoids point snapping
            # issues that cause NA holes when rasterizing from SpatVector points
            r <- terra::rast(sub, type = "xyz", crs = "OGC:CRS84")

            # Resample to standard LUH2 template to ensure consistent grid alignment
            terra::resample(r, template, method = "near")
        }))

        names(pool_stack) <- yrs_seq
        out_path <- file.path(output_dir, paste0("lu_", pool, ".tif"))
        terra::writeRaster(pool_stack, out_path, overwrite = TRUE)
        message("Written: ", basename(out_path))
        result[[pool]] <- pool_stack
    }

    invisible(result)
}
