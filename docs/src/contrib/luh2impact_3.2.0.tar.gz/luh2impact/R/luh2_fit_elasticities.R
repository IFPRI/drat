#' Fit land use elasticities to cropland and GDP per capita
#'
#' Builds a per-country annual panel of land use areas and GDP per capita,
#' fills interior gaps by linear interpolation, first-differences the logs,
#' and fits one OLS regression per country and per non-cropland pool of that
#' pool's log change on the log changes in cropland and GDP per capita.
#'
#' @details
#' The fitted model, for each country and each of `past`, `natfor`, `other`
#' and `plant`, is
#' `dln_use ~ dln_crop + dln_gdppc`,
#' where `dln_x` is the year-on-year change in `log(x)`. The coefficients are
#' therefore elasticities of that pool's area with respect to cropland area
#' and income. They are descriptive associations within a country's own
#' history, estimated without controls or instruments, and should not be
#' read as causal effects.
#'
#' Data handling worth knowing about: years missing inside a country's range
#' are linearly interpolated (leading and trailing gaps are left alone);
#' non-positive areas become `NA` before the logs are taken; only years
#' present in both the FAOSTAT and GDP per capita inputs are used. Estimates
#' are clipped to `[-4, 4]` for cropland and `[-2, 2]` for GDP per capita,
#' which bounds the small-sample tails rather than describing the data.
#'
#' Every country and pool appears in the output, including those that could
#' not be fitted, distinguished by `flag`:
#' \describe{
#'   \item{`ok`}{Fitted, both terms present.}
#'   \item{`insufficient_obs`}{Fewer than `min_obs` complete observations;
#'     both elasticities set to 0.}
#'   \item{`model_failed`}{[stats::lm()] errored; both elasticities set
#'     to 0.}
#'   \item{`dropped_term`}{Fitted, but a term was dropped (collinearity),
#'     and the missing elasticity is reported as 0.}
#' }
#' [luh2_export_elasticities_gdx()] writes all rows as `LANDELAS_RAW_*` but
#' restricts `LANDELAS`, the parameter the model actually solves with, to
#' `ok` rows.
#'
#' @param faoland A data frame returned by [luh2_load_faoland()].
#' @param gdppc A data frame returned by [luh2_compute_gdppc()].
#' @param year_max Integer. Latest year to include in the panel.
#'   Default `2023`.
#' @param min_obs Integer. Minimum number of complete observations needed to
#'   fit a country's regression. Default `10`.
#'
#' @return A list with two elements:
#' \describe{
#'   \item{`results`}{One row per country and land use, with `elast_crop`
#'     and `elast_gdppc` (clipped as above), their standard errors
#'     (`se_crop`, `se_gdppc`) and p-values (`pval_crop`, `pval_gdppc`),
#'     `n_obs`, and `flag`. Standard errors and p-values are `NA` where no
#'     model was fitted.}
#'   \item{`wide_imputed`}{The imputed panel the regressions were fitted to
#'     (`cty`, `year`, `land`, `crop`, `past`, `natfor`, `plant`, `other`,
#'     `gdppc`), kept so the inputs can be inspected.}
#' }
#' @family country pipeline functions
#' @author Abhijeet Mishra, Claude Code
#' @examples
#' \dontrun{
#' fit <- luh2_fit_elasticities(faoland, gdppc)
#' table(fit$results$flag)
#' }
#' @export
luh2_fit_elasticities <- function(faoland, gdppc, year_max = 2023, min_obs = 10) {
    non_crop_uses <- c("past", "natfor", "other", "plant")

    df <- rbind(faoland, gdppc)
    df <- df[order(df$cty, df$year), ]
    df <- df[df$year %in% intersect(unique(faoland$year), unique(gdppc$year)), ]

    wide <- df |>
        dplyr::filter(year <= year_max) |>
        dplyr::select(cty, item, year, value) |>
        tidyr::pivot_wider(names_from = item, values_from = value) |>
        dplyr::arrange(cty, year)

    wide_imputed <- wide |>
        dplyr::group_by(cty) |>
        tidyr::complete(year = seq(min(year), max(year))) |>
        dplyr::mutate(dplyr::across(c(crop, dplyr::all_of(non_crop_uses), gdppc, land), .luh2_approx_na)) |>
        dplyr::ungroup()

    fd <- wide_imputed |>
        dplyr::group_by(cty) |>
        dplyr::mutate(dplyr::across(c(crop, dplyr::all_of(non_crop_uses), gdppc),
                                    \(x) c(NA, diff(log(ifelse(x <= 0, NA, x)))),
                                    .names = "dln_{.col}")) |>
        dplyr::ungroup() |>
        dplyr::filter(!is.na(dln_crop))

    fit_elasticity <- function(data, use) {
        dv  <- paste0("dln_", use)
        frm <- stats::as.formula(paste(dv, "~ dln_crop + dln_gdppc"))

        data |>
            dplyr::group_by(cty) |>
            dplyr::group_map(\(d, g) {
                d_clean <- d |> dplyr::select(dplyr::all_of(c(dv, "dln_crop", "dln_gdppc"))) |> tidyr::drop_na()
                n_obs <- nrow(d_clean)

                if (n_obs < min_obs) {
                    data.frame(cty = g$cty, land_use = use,
                              elast_crop = 0, se_crop = NA_real_, pval_crop = NA_real_,
                              elast_gdppc = 0, se_gdppc = NA_real_, pval_gdppc = NA_real_,
                              n_obs = n_obs, flag = "insufficient_obs")
                } else {
                    fit <- tryCatch(stats::lm(frm, data = d_clean), error = \(e) NULL)
                    if (is.null(fit)) {
                        data.frame(cty = g$cty, land_use = use,
                                  elast_crop = 0, se_crop = NA_real_, pval_crop = NA_real_,
                                  elast_gdppc = 0, se_gdppc = NA_real_, pval_gdppc = NA_real_,
                                  n_obs = n_obs, flag = "model_failed")
                    } else {
                        coef_tbl <- summary(fit)$coefficients
                        data.frame(
                            cty = g$cty, land_use = use,
                            elast_crop  = .luh2_safe_coef(coef_tbl, "dln_crop",  "Estimate", 0),
                            se_crop     = .luh2_safe_coef(coef_tbl, "dln_crop",  "Std. Error"),
                            pval_crop   = .luh2_safe_coef(coef_tbl, "dln_crop",  "Pr(>|t|)"),
                            elast_gdppc = .luh2_safe_coef(coef_tbl, "dln_gdppc", "Estimate", 0),
                            se_gdppc    = .luh2_safe_coef(coef_tbl, "dln_gdppc", "Std. Error"),
                            pval_gdppc  = .luh2_safe_coef(coef_tbl, "dln_gdppc", "Pr(>|t|)"),
                            n_obs = n_obs,
                            flag = if (any(!c("dln_crop", "dln_gdppc") %in% rownames(coef_tbl))) "dropped_term" else "ok"
                        )
                    }
                }
            }, .keep = TRUE) |>
            dplyr::bind_rows()
    }

    results <- lapply(non_crop_uses, function(u) fit_elasticity(fd, u)) |>
        dplyr::bind_rows() |>
        dplyr::arrange(land_use, cty) |>
        dplyr::mutate(
            elast_crop  = pmax(-4, pmin(4, elast_crop)),
            elast_gdppc = pmax(-2, pmin(2, elast_gdppc))
        )

    list(results = results, wide_imputed = wide_imputed)
}
