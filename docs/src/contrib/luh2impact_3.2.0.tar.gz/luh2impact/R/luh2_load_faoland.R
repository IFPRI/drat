#' Load FAOSTAT land use data and map it to IMPACT countries
#'
#' Reads the FAOSTAT "Inputs: Land Use" bulk download, keeps the items used
#' for elasticity estimation, maps FAO countries to IMPACT regions, and sums
#' to IMPACT country level. This is the starting point of the country-level
#' pipeline.
#'
#' @details
#' Only records reported in 1000 ha are kept, and FAOSTAT items are renamed
#' to the pool names used throughout the package:
#' \describe{
#'   \item{`land`}{Land area - the country total, not one of the pools.}
#'   \item{`crop`}{Cropland.}
#'   \item{`past`}{Permanent meadows and pastures.}
#'   \item{`natfor`}{Naturally regenerating forest.}
#'   \item{`plant`}{Planted Forest.}
#'   \item{`other`}{Other land.}
#' }
#' The FAO country code to IMPACT region mapping is read from the `Regions`
#' sheet of `sets_xlsx` (columns `FCTY` and `CTY`), and FAO countries with no
#' IMPACT region are dropped rather than pooled into a residual. Several FAO
#' countries can map to one IMPACT region, in which case their areas are
#' summed.
#'
#' @param fao_land_csv Path to the FAOSTAT
#'   `Inputs_LandUse_E_All_Data_(Normalized).csv` file.
#' @param sets_xlsx Path to the IMPACT `Sets.xlsx` workbook. Must contain a
#'   `Regions` sheet mapping FAO country codes (`FCTY`) to IMPACT regions
#'   (`CTY`).
#' @param year_min Integer. Earliest year to retain. Default `1995`.
#'
#' @return A data frame with columns `cty`, `item`, `year`, `unit` and
#'   `value` (1000 ha), one row per country, item and year.
#' @family country pipeline functions
#' @author Abhijeet Mishra, Claude Code
#' @examples
#' \dontrun{
#' faoland <- luh2_load_faoland(
#'     fao_land_csv = "data/FAOSTAT/Inputs_LandUse_E_All_Data_(Normalized).csv",
#'     sets_xlsx    = "data/IMPACT/Sets.xlsx"
#' )
#' head(faoland)
#' }
#' @export
luh2_load_faoland <- function(fao_land_csv, sets_xlsx, year_min = 1995) {
    faoland <- as.data.frame(data.table::fread(file = fao_land_csv, header = TRUE))
    names(faoland) <- tolower(names(faoland))

    itemlist <- c("Land area", "Cropland", "Naturally regenerating forest",
                  "Other land", "Permanent meadows and pastures", "Planted Forest")

    faoland <- faoland[faoland$unit %in% "1000 ha" & faoland$item %in% itemlist,
                       c("area code", "item", "year", "unit", "value")]
    names(faoland)[1] <- "fcty"
    faoland$fcty <- as.numeric(faoland$fcty)

    faoland$item <- factor(faoland$item,
                           levels = c("Land area",
                                      "Cropland", "Permanent meadows and pastures",
                                      "Naturally regenerating forest", "Planted Forest",
                                      "Other land"),
                           labels = c("land",
                                      "crop", "past",
                                      "natfor", "plant",
                                      "other"))

    ctyset  <- .luh2_read_ctyset(sets_xlsx)
    faoland <- dplyr::left_join(faoland, ctyset, by = "fcty")
    faoland <- faoland[!is.na(faoland$cty), ]

    faoland <- faoland |>
        dplyr::group_by(cty, item, year, unit) |>
        dplyr::summarise(value = sum(value, na.rm = TRUE), .groups = "drop")

    faoland <- as.data.frame(faoland[faoland$year >= year_min, ])
    faoland
}
