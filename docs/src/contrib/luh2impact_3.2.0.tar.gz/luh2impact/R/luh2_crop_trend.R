#' Compute the per-pixel crop expansion trend
#'
#' Fits a per-pixel linear trend over time to the summed crop land use shares
#' (`c3ann`, `c4ann`, `c3per`, `c4per`, `c3nfx`) and returns the slope, i.e.
#' the change in crop share per year over the requested period.
#'
#' @details
#' This is the crop-only special case of [luh2_pool_trend()], kept because it
#' is convenient on its own. [luh2_pool_trend()] is faster (it solves the OLS
#' slope analytically instead of calling [stats::lm()] per pixel) and is what
#' [luh2gdx()] uses for all pools, crop included.
#'
#' @param luh A `SpatRaster` returned by [luh2_load()].
#' @param year_start Integer. First year of the trend period (e.g. 1990).
#' @param year_end Integer. Last year of the trend period (e.g. 2015).
#'
#' @return A single-layer `SpatRaster` named `"crop_slope"`, in share per
#'   year. Pixels that are `NA` in every year stay `NA`.
#' @seealso [luh2_pool_trend()] for the general, faster version.
#' @family pixel pipeline functions
#' @author Abhijeet Mishra, Claude Code
#' @examples
#' \dontrun{
#' luh <- luh2_load("data/LUH2/states.nc")
#' crop_slope <- luh2_crop_trend(luh, year_start = 1990, year_end = 2015)
#' }
#' @export
luh2_crop_trend <- function(luh, year_start, year_end) {
    crop_vars <- c("c3ann", "c4ann", "c3per", "c4per", "c3nfx")

    luh_start <- as.integer(terra::time(luh)[1])

    suffix_start <- year_start - luh_start + 1
    suffix_end   <- year_end   - luh_start + 1
    suffixes     <- seq(suffix_start, suffix_end)

    crop_stack <- terra::rast(lapply(suffixes, function(s) {
        layers    <- paste0(crop_vars, "_", s)
        available <- layers[layers %in% names(luh)]
        if (length(available) == 0) stop("No crop layers found for suffix ", s)
        terra::app(luh[[available]], fun = "sum", na.rm = TRUE)
    }))

    time_idx <- seq_along(suffixes) # nolint: object_usage_linter

    crop_trend <- terra::app(crop_stack, function(x) {
        if (all(is.na(x))) return(NA_real_)
        stats::coef(stats::lm(x ~ time_idx))[2]
    })

    names(crop_trend) <- "crop_slope"
    crop_trend
}
