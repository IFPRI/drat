#' @title luh2impact: land use inputs for IMPACT and LUMEN
#'
#' @description
#' Turns raw land use data into the parameters that the IMPACT economic model
#' and its LUMEN pixel-level land use downscaler read as inputs. The package
#' holds two independent pipelines that share a country definition (the IMPACT
#' regions shapefile / `Sets.xlsx` workbook) but nothing else.
#'
#' @section Pixel pipeline (LUH2 to LUMEN):
#' Produces a 0.25 degree pixel table and the LUMEN input GDX. Run end to end
#' with [luh2gdx()], or step by step:
#' \enumerate{
#'   \item [luh2_load()] - read LUH2 `states.nc`.
#'   \item [luh2_extract_year()] - shares to areas for one year, plus the
#'     static grid layers.
#'   \item [luh2_pool_trend()] / [luh2_crop_trend()] - per-pixel historical
#'     trends used as reallocation weights.
#'   \item [luh2_suitability()] - long-run mean share per pool, used as a
#'     suitability index.
#'   \item [luh2_merge_planted()] - carve planted forest out of the LUH2 pools.
#'   \item [wdpa_process()] - rasterize WDPA protected areas onto the LUH2 grid.
#'   \item [luh2_build_pixels()] - assemble the pixel table and rebalance it to
#'     IMPACT country totals.
#'   \item [luh2_export_gdx()] - write the LUMEN input GDX.
#' }
#' After LUMEN solves, [luh2_write_tifs()], [luh2_plot_results()] and
#' [luh2_plot_bii()] turn the solution GDX back into rasters and figures.
#'
#' @section Country pipeline (FAOSTAT to IMPACT):
#' Produces the country-level `LAND00`, `LANDELAS`, `LANDPA00` and `BII_COEFF`
#' parameters read by the IMPACT land use module. Run end to end with
#' [luh2_landuse_elasticities()], or step by step:
#' \enumerate{
#'   \item [luh2_load_faoland()] - FAOSTAT land use areas mapped to IMPACT
#'     regions.
#'   \item [luh2_compute_gdppc()] - SSP GDP per capita with a World Bank
#'     fallback.
#'   \item [luh2_fit_elasticities()] - per-country regressions of each
#'     non-cropland pool on cropland and GDP per capita.
#'   \item [luh2_urban_area_cty()] and [luh2_pa_area_cty()] - urban and
#'     protected area totals per country.
#'   \item [luh2_bii_coeff_cty()] or [luh2_bii_coeff_cty_pixel()] -
#'     biodiversity intactness coefficients per country and pool.
#'   \item [luh2_export_elasticities_gdx()] - write the IMPACT input GDX.
#' }
#' [luh2_plot_elasticities()] visualises the fitted elasticities.
#'
#' @section Land pools:
#' Both pipelines use the same six pools: `crop`, `past` (pasture and
#' rangeland), `natfor` (naturally regenerating forest), `plant` (planted
#' forest), `other` (all remaining non-forest natural land) and `urban`.
#' Protected area is deliberately *not* a pool - it overlays `natfor`, `past`
#' and `other` - and is carried separately as an area floor.
#'
#' @section Input data:
#' None of the input data ships with the package; every entry point takes file
#' paths. The expected inputs are LUH2 `states.nc` and
#' `staticData_quarterdeg.nc`, a planted forest GeoTIFF (e.g. SDPT), the WDPA
#' geodatabase, the IMPACT regions shapefile and `Sets.xlsx`, the FAOSTAT
#' "Inputs: Land Use" bulk CSV, an SSP scenario GDX, and a World Bank GDP per
#' capita (PPP) CSV. The only data shipped with the package are the
#' pre-computed pixel BII coefficient tables under `inst/extdata` used by
#' [luh2_bii_coeff_cty_pixel()].
#'
#' @section GDX support:
#' Every function that reads or writes a GDX file needs the `gamstransfer`
#' package, which is distributed with GAMS rather than from CRAN. It is listed
#' under `Suggests`, so the rest of the package installs and loads without it.
#'
#' @keywords internal
"_PACKAGE"
