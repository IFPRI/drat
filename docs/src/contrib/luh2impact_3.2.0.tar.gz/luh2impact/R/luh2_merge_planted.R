#' Merge a planted forest layer into the LUH2 shares
#'
#' Aggregates the LUH2 states into the pools used downstream, splits natural
#' land into forest and non-forest, then carves the planted forest area out
#' of the existing pools so that the shares still sum to at most 1. LUH2 has
#' no planted forest class of its own, so the area has to be taken from
#' somewhere rather than added on top.
#'
#' @details
#' Pools are built from the LUH2 states as: `crop` = c3ann + c4ann + c3per +
#' c4per + c3nfx; `natfor` = primf + secdf + primn + secdn; `range` = range +
#' pastr; `urban` = urban; `other` = primn + secdf + secdn. `natfor` and
#' `other` deliberately overlap at this point and are then separated with the
#' LUH2 forest/non-forest flag: `natfor` is multiplied by `fstnf` and `other`
#' by `1 - fstnf`. South Africa (`ZAF`) is hard-coded as an exception and
#' keeps both pools unscaled; the reason for that exception is not recorded
#' in the source.
#'
#' Planted forest is then carved out in a fixed order: first from `other`,
#' then whatever is left from `range`. Any residual planted share is capped
#' at the space still free after all LUH2 pools, so it can be silently
#' reduced where the grid is already full.
#'
#' @param luarea A `SpatRaster` of land use areas in km^2, the `luarea`
#'   element of the list returned by [luh2_extract_year()].
#' @param cellarea A single-layer `SpatRaster` of cell areas in km^2, the
#'   `cellarea` element of the same list.
#' @param planted_tif Path to a planted forest GeoTIFF giving planted forest
#'   area in km^2 per cell on the LUH2 grid (e.g. an SDPT-derived
#'   `sdpt_global.tif`).
#' @param fstnf A single-layer `SpatRaster` forest/non-forest flag (1 where
#'   the potential vegetation is forest), the `fstnf` element of the list
#'   returned by [luh2_extract_year()].
#' @param cty_shp Path to the IMPACT regions shapefile. Must contain a
#'   `NEW_REGION` field used as the country identifier; only used here to
#'   identify South Africa for the exemption described above.
#'
#' @return A `SpatRaster` of adjusted shares (0 to 1) with one layer per
#'   pool: `crop_share`, `natfor_share`, `range_share`, `urban_share`,
#'   `other_share` and `planted_forest_share`. [luh2_build_pixels()] renames
#'   `range_share` to `past_share` and `planted_forest_share` to
#'   `plant_share`.
#' @family pixel pipeline functions
#' @author Abhijeet Mishra, Claude Code
#' @examples
#' \dontrun{
#' luh       <- luh2_load("data/LUH2/states.nc")
#' extracted <- luh2_extract_year(luh, "data/LUH2/staticData_quarterdeg.nc", 2015)
#' shares    <- luh2_merge_planted(
#'     luarea      = extracted$luarea,
#'     cellarea    = extracted$cellarea,
#'     planted_tif = "data/SDPT/sdpt_global.tif",
#'     fstnf       = extracted$fstnf,
#'     cty_shp     = "data/IMPACT/impact_regions.shp"
#' )
#' }
#' @export
luh2_merge_planted <- function(luarea, cellarea, planted_tif, fstnf, cty_shp) {
    cty <- terra::vect(cty_shp)
    names(cty)[names(cty) %in% "NEW_REGION"] <- "cty"

    # Project to match LUH2 CRS exactly
    cty <- terra::project(cty, "OGC:CRS84")
    # touches = TRUE ensures border pixels are assigned to a country rather than
    # dropped as NA, preventing holes along country edges
    cty_rast <- terra::rasterize(cty, luarea[[1]], field = "cty", touches = TRUE)

    # Fir all natural land is in one prim and secd (f/n)
    pool_map <- list(
        crop   = c("c3ann", "c4ann", "c3per", "c4per", "c3nfx"),
        natfor = c("primf", "secdf", "primn", "secdn"),
        range  = c("range", "pastr"),
        urban  = "urban",
        other = c("primn", "secdf", "secdn")
    )

    pool_areas <- terra::rast(lapply(names(pool_map), function(pool) {
        layers <- pool_map[[pool]][pool_map[[pool]] %in% names(luarea)]
        if (length(layers) == 0) stop("No layers found for pool: ", pool)
        r <- terra::app(luarea[[layers]], fun = "sum", na.rm = TRUE)
        names(r) <- pool
        r
    }))

    pool_areas$natfor <- terra::ifel(cty_rast == "ZAF",
                                     pool_areas$natfor,
                                     pool_areas$natfor * fstnf)
    pool_areas$other <- terra::ifel(cty_rast == "ZAF",
                                    pool_areas$other,
                                    pool_areas$other * (1 - fstnf))

    plant_total <- terra::rast(planted_tif)

    all_layers <- c(pool_areas, plant_total)
    names(all_layers)[terra::nlyr(all_layers)] <- "planted_forest"

    shares <- all_layers / cellarea
    names(shares) <- paste0(names(all_layers), "_share")

    planted <- shares[["planted_forest_share"]]

    # Carve from other first
    pool <- "other"
    pooln <- paste0(pool, "_share")
    take_from_pool <- terra::lapp(
        c(planted, shares[[pooln]]),
        fun = function(a, b) pmin(a, b)
    )
    shares[[pooln]] <- shares[[pooln]] - take_from_pool
    planted_remaining <- planted - take_from_pool

    # Then carve from past
    pool <- "range"
    pooln <- paste0(pool, "_share")
    take_from_pool <- terra::lapp(
        c(planted_remaining, shares[[pooln]]),
        fun = function(a, b) pmin(a, b)
    )
    shares[[pooln]] <- shares[[pooln]] - take_from_pool

    # Cap residual planted at remaining space
    luh2_pools <- c("crop_share", "natfor_share", "range_share", "other_share", "urban_share")
    luh2_total <- terra::app(shares[[luh2_pools]], fun = "sum", na.rm = TRUE)

    shares[["planted_forest_share"]] <- terra::lapp(
        c(luh2_total, shares[["planted_forest_share"]]),
        fun = function(a, b) pmin(b, pmax(1 - a, 0))
    )

    shares
}
