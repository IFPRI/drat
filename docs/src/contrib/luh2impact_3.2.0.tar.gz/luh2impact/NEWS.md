# luh2impact 3.2.0

* Documentation overhaul ahead of publishing the package. Roxygen markdown is
  now enabled (`Roxygen: list(markdown = TRUE)` in `DESCRIPTION`), so the
  `[function()]` cross-references and backticked code in every help page now
  render as links and code rather than as literal text.
* Added a package overview page (`?luh2impact`) and a README describing both
  pipelines, the required input data, and the known limitations.
* Exported functions are grouped into `pixel pipeline functions`,
  `country pipeline functions` and `output functions` families, so each help
  page links to its neighbours.
* Documented behaviour that was previously only visible in the source: the
  iterative proportional fitting in `luh2_build_pixels()` and its fixed 2021
  control year, the full list of GDX symbols written by `luh2_export_gdx()`
  and `luh2_export_elasticities_gdx()`, the hard-coded band cache and layer
  name in `wdpa_process()`, the South Africa exemption in
  `luh2_merge_planted()`, and the LUH2 epoch assumed by `luh2_suitability()`.
* Corrected `luh2_extract_year()` (its return value documented three of five
  elements), `luh2_plot_results()` (the returned list was named wrongly), and
  `wdpa_process()` (`static_nc` is a file path, not a `SpatRaster`).
* `DESCRIPTION`: added `stats` and `utils` to `Imports`, declared
  `R (>= 4.1)`, added `URL` and `BugReports`, and dropped `LazyData`, which
  the package has no `data/` directory for.

# luh2impact 3.1.1

* `luh2_bii_coeff_cty_pixel()` now defaults to a BII coefficient table built
  from Nguyen's `Landuse_Fraction` rasters, which are co-registered with the
  BII raster, instead of the earlier table built from the 500 m HHLU raster
  through a custom cross-resolution alignment. The two agree to correlations
  above 0.9999 on every pool. Both tables ship under `inst/extdata` and
  either can be passed to `pixel_csv`.

# luh2impact 3.1.0

* Added `luh2_bii_coeff_cty_pixel()`, giving country-specific BII
  coefficients for all six land pools from pixel imagery, as an alternative
  to the literature-based `luh2_bii_coeff_cty()`.

# luh2impact 3.0.0

* Added the country-level FAOSTAT pipeline feeding IMPACT directly, rather
  than only the LUMEN pixel downscaler: `luh2_load_faoland()`,
  `luh2_compute_gdppc()`, `luh2_fit_elasticities()`,
  `luh2_export_elasticities_gdx()` and the `luh2_landuse_elasticities()`
  wrapper.
* Added protected area support through `wdpa_process()` and
  `luh2_pa_area_cty()`, written as an aggregate `LANDPA00` floor rather than
  as a land cover pool, and carried into the pixel table as `pa_area`.
* Added urban land as a fixed baseline pool via `luh2_urban_area_cty()`.
* Added `luh2_natfor_primary_share_cty()` and `luh2_bii_coeff_cty()` for
  country-level biodiversity intactness coefficients.
* Added `luh2_plot_elasticities()` and `luh2_plot_bii()`.

# luh2impact 2.2.0

* Added `luh2_suitability()`, a long-run mean share per pool used to weight
  reallocation, and exported it to LUMEN as the `suit` parameter.

# luh2impact 2.1.0

* Refinements to `luh2_plot_results()`, `luh2_pool_trend()` and
  `luh2_merge_planted()`.

# luh2impact 2.0.0

* `luh2_build_pixels()` now reconciles pixel areas to the IMPACT country
  totals by iterative proportional fitting, and computes per-country
  allocation weights for crop, natural forest, other land, pasture and
  planted forest.

# luh2impact 1.0.0

* First release: the LUH2 to LUMEN pixel pipeline.
